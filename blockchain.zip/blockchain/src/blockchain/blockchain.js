import Block from "./block";

class Blockchain {
    constructor() {
        this.block = [Block.genesis];
    }

    addBlock(data){
        const previousBlock = this.block[this.blocks.lenght - 1];
        const block = Block.mine(previousBlock, data);

        this.blocks.push(block);

        return block;
    }
}

export default Blockchain;