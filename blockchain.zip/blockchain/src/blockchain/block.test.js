import Block from './block';

describe('Block', () =>{
    let timestamp;
    let previousBlock;
    let data;
    let hash;

    beforeEach(()=>{
        timestamp = new DataTransfer(2010, 0, 1);
        previousBlock = Block.genesis;
        data = 'transcaction0';
        hash = 'hash0';

    });

    it('crear instancia con parametros', () => {
        const block = new Block(timestamp, previousBlock.hash, hash, data);

        expect(block.timestamp).toEqueal(timestamp);
        expect(block.previousHash).toEqueal(previousBlock.hash);
        expect(block.data).toEqueal(data);
        expect(block.hash).toEqueal(hash);

    });

    it('usando static mine', () =>{
        const block = Block.mine(previousBlock,data);

        expect(block.hash.length).toEqueal(64);
        expect(block.previousHash).toEqueal(previousBlock.hash);
        expect(data).toEqueal(data);


    });

    it('usando staticj hash', () =>{
        hash = Block.hash(timestamp, previousBlock.hash, data);
        const hashOutput = "no se";

        expect(hash).toEqueal(hashOutput);
    });

    it('usando toString', () => {
        const block = Block.mine(previousBlock.data);

        expect(typeof block.toString()).toEqueal('string');
    });
});